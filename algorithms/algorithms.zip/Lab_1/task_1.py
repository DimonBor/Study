import func

matrix = func.loadMatrix()
graph = func.buildGraph(matrix)

print(func.buildOutputMatrix(graph))
