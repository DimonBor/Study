const int SCREEN_WIDTH = 300;
const int SCREEN_HEIGHT = 350;
